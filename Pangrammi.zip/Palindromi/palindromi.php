<?php
$pali = $_POST["pali"];

$reverse = strrev($pali);

if($pali == $reverse) {
   echo '<br>' .$pali.' on palindromi';
}

else if ($pali != $reverse) {echo '<br>'.$pali.' ei ole palindromi';
}

?>