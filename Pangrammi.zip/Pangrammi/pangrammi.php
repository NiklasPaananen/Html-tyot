<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pangrammi</title>
</head>
<body>
<form method="post">
<label for="sentence">Kirjoita sana tähän:</label><br>
<input type="text" id="sentence" name="sentence" required><br>
<button type="submit" name="check">Onko sana pangrammi?</button>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") 
    // Otetaan vastaan syöte lomakkeesta
    $input = $_POST["sentence"];
function isPangram($sentence) {
    // Muutetaan syöte pieniksi kirjaimiksi
    $lowercaseSentence = strtolower($sentence);
    
    // Luodaan taulukko aakkosista
    $alphabet = range('a', 'z');
    
    // Käydään läpi aakkoset ja tarkistetaan, esiintyykö ne annetussa lauseessa
    foreach ($alphabet as $letter) {
        // Tarkistetaan, esiintyykö kirjain lauseessa
        if (strpos($lowercaseSentence, $letter) === false) {
            // Jos kirjainta ei esiinny, palautetaan false, sillä lause ei ole pangrammi
            return false;
        }
    }
    
    // Jos kaikki aakkoset esiintyvät lauseessa, palautetaan true, eli lause on pangrammi
    return true;
}

// Tarkistetaan, onko syöte pangrammi ja tulostetaan vastaava viesti
if (isPangram($input)) {
    echo "Sana tai lause on pangrammi\n";
} else {
    echo "Sana tai lause ei ole pangrammi\n";
}

?>
</form>
</body>
</html>