<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painoindeksi</title>
<head>
<body>
<h1>Painoindeksilaskuri</h1>
<form method="post">
<div>
<label for="weight">Paino (kg):</label>
            <input type="number" id="weight" name="weight" required>
        </div>
        <div>
            <label for="height">Pituus (m):</label>
            <input type="number" id="height" name="height" step="0.01" required>
        </div>
        <button type="submit" name="calculate">Laske painoindeksi</button>
    </form>

<?php

// Tarkistetaan, onko lomaketta lähetetty
if(isset($_POST['calculate'])) {
    // Otetaan käyttäjän syötteet
    $weight = floatval($_POST['weight']);
    $height = floatval($_POST['height']);

    // Lasketaan painoindeksi
    $bmi = ($weight * 1.3) / pow($height, 2.5);

    // Näytetään tulos
    echo "<div style='margin-top: 20px;'><p>Painoindeksi: " . number_format($bmi, 2) . "</p></div>";
}
?>

</body>
</html>